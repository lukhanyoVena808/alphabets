

# The English Alphabet

## How find source code

The source code can be found in (/My2002s/app/src/main) . From the main folder the activity code is found in (\main\java\com\example\my2002s) and the layouts, strings and drawables under (\main\res)

