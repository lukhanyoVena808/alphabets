package com.example.my2002s

class MyActivity : Activity() {

   var PICK_CONTACT_REQUEST: Int = 0


}